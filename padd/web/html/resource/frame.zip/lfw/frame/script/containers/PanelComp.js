/**
 * @fileoverview Panel控件
 * 
 * @author dengjt, gd, guoweic
 * @version NC6.0
 * 
 */
PanelComp.prototype = new BaseComponent;
PanelComp.prototype.componentType = "PANEL";

/**
 * PanelComp布局构造函数
 * 
 * @class Panel布局
 * @param parent 父对象
 * @param name 名称
 * @param left 
 * @param top 
 * @param width 宽度
 * @param height 高度
 * @param position 位置
 * @param scroll 是否有滚动条
 * @param transparent: 背景是否透明
 * @param attrArr: 附加属性：
 * 					1、isRoundRect 是否是圆角
 * 					2、radius      圆角半径
 * 					3、withBorder 是否有边框
 * 					4、borderWidth 边框宽度
 * 					5、borderColor 边框颜色
 * 
 */
function PanelComp(parent, name, left, top, width, height, position, scroll,
		className, transparent, background, attrArr) {
	if (arguments.length == 0)
		return;

	this.base = BaseComponent;
	this.base(name, left, top, width, height);
	this.parentOwner = parent;
	this.position = getString(position, "absolute");
	this.scroll = getBoolean(scroll, false);
	this.overflow = this.scroll ? "auto" : "hidden";
	this.className = getString(className, "panel_div");
	this.background = background;
	if (transparent == true) {
		this.transparent = true;
		this.className = "panel_transparent_div";
	}
	if (attrArr != null) {
		this.isRoundRect = attrArr.isRoundRect;
		this.radius = attrArr.radius;
		this.withBorder = attrArr.withBorder;
		this.borderWidth = attrArr.borderWidth;
		this.borderColor = attrArr.borderColor;
	}
	this.create();
};

/**
 * @private
 */
PanelComp.prototype.create = function() {
	this.Div_gen = $ce("DIV");
	this.Div_gen.id = this.id;
	this.Div_gen.style.left = this.left + "px";
	this.Div_gen.style.top = this.top + "px";
	this.Div_gen.style.width = this.width;
	this.Div_gen.style.height = this.height;
	this.Div_gen.style.position = this.position;
	this.Div_gen.style.overflow = this.overflow;
	this.Div_gen.className = this.className;
	
	if (!this.transparent && this.background != "") {
		this.Div_gen.style.background = this.background;
	}

	if (this.parentOwner)
		this.placeIn(this.parentOwner);
	
	// 有边框
	if (this.withBorder && this.borderWidth != null) {
		this.Div_gen.style.width = (this.Div_gen.offsetWidth - 2 * this.borderWidth) + "px";
		this.Div_gen.style.height = (this.Div_gen.offsetHeight - 2 * this.borderWidth) + "px";
		this.Div_gen.style.borderStyle = "solid";
		this.Div_gen.style.borderWidth = this.borderWidth + "px";
		if (this.borderColor != null)
			this.Div_gen.style.borderColor = this.borderColor;
	}
	
	if (this.isRoundRect && this.radius != null) {  // 圆角
		this.round();
	}
	
};

/**
 * 设置为圆角
 */
PanelComp.prototype.round = function() {
	var settings = {
    	tl: { radius: this.radius },
    	tr: { radius: this.radius },
    	bl: { radius: this.radius },
    	br: { radius: this.radius },
    	antiAlias: true
	};
	return curvyCorners(settings, this.Div_gen.id);
};

/**
 * 设置Padding属性
 */
PanelComp.prototype.setPadding = function(left, top, right, bottom) {
	this.Div_gen.style.paddingLeft = left ? left + "px" : "0" + "px";
	this.Div_gen.style.paddingTop = top ? top + "px" : "0" + "px";
	this.Div_gen.style.paddingRight = right ? right + "px" : "0" + "px";
	this.Div_gen.style.paddingBottom = bottom ? bottom + "px" : "0" + "px";
};

/**
 * 设置内容
 */
PanelComp.prototype.setContent = function(obj) {
	this.Div_gen.appendChild(obj);
};

/**
 * 设置是否有滚动条
 * 
 * @param scroll 是否有滚动条
 */
PanelComp.prototype.setScroll = function(scroll) {
	this.scroll = getBoolean(scroll, false);
	this.overflow = this.scroll ? "auto" : "hidden";
	this.Div_gen.style.overflow = this.overflow;
};

/**
 * 设置是否渲染
 */
PanelComp.prototype.setDisplay = function(display) {
	this.parentOwner.style.display = display == true ? "block" : "none";
	this.display = display;
};

/**
 * 设置可见性
 */
PanelComp.prototype.setVisible = function(visible) {
	this.parentOwner.style.visibility = visible == true ? "visible" : "hidden";
	this.visible = visible;
};

/**
 * @private
 */
PanelComp.prototype.getContext = function() {
	var context = new Object;
//	context.javaClass = "nc.uap.lfw.core.comp.ctx.PanelContext";
	context.c = "PanelContext";
	context.id = this.id;
	context.display = this.display;
	context.visible = this.visible;
	return context;
};

/**
 * @private
 */
PanelComp.prototype.setContext = function(context) {
	if (context.display != null && context.display != this.display)
		this.setDisplay(context.display);
	if (context.visible != null && context.visible != this.visible)
		this.setVisible(context.visible);
	
};

