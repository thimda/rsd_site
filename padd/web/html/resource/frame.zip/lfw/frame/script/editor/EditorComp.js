/**
 * @fileoverview WebFrame Editor控件定义文件
 * @author gd, dengjt, guoweic
 * @version NC6.0
 * 
 * 注：一个页面只能有一个EditorComp控件！（因为设置了window.currentEditor）
 */
EditorComp.prototype = new BaseComponent;
EditorComp.prototype.componentType = "EDITOR";
EditorComp.ROW_HEIGHT = 25;
EditorComp.ACTION_LIST = [
                      	[{index:3,title:"字体颜色",click:"foreColor", src:"fgcolor.gif"},
                      	 {index:4,title:"字体背景颜色",click:"backColor", src:"fbcolor.gif"},
                      	 {index:5,title:"插入特殊符号",click:"insertSpecialChar", src:"specialchar.gif"},
                      	 {index:6,title:"替换",click:"oblog_replace", src:"replace.gif"},
                      	 {index:7,title:"清除格式",click:"oblog_CleanCode", src:"cleancode.gif"}
                      	],
                      	[{index:0,title:"全选",click:"selectAll", src:"selectAll.gif"},
                      	 {index:1,title:"剪切",click:"cut", src:"cut.gif"},
                      	 {index:2,title:"复制",click:"copy", src:"copy.gif"},
                      	 {index:3,title:"粘贴",click:"paste", src:"paste.gif"},
                      	 {index:4,title:"撤消",click:"undo", src:"undo.gif"},
                      	 {index:5,title:"恢复",click:"redo", src:"redo.gif"},
                      	 {index:6,title:"插入超级链接",click:"oblog_forlink", src:"wlink.gif"},
                      	 {index:7,title:"去掉超级链接",click:"unlink", src:"unlink.gif"},
                      	 {index:8,title:"插入图片",click:"oblog_forimg", src:"img.gif"},
                      	 {index:9,title:"插入水平线",click:"drawHr", src:"hr.gif"},
                      	 {index:10,title:"插入表格",click:"fortable", src:"table.gif"},
                      	 {index:11,title:"插入行",click:"insertTableRow", src:"insertrow.gif"},
                      	 {index:12,title:"删除行",click:"deleteTableRow", src:"deleterow.gif"},
                      	 {index:13,title:"插入列",click:"insertTableColumn", src:"insertcolumn.gif"},
                      	 {index:14,title:"删除列",click:"deleteTableColumn", src:"deletecolumn.gif"}
                      	],
                      	[{index:0,title:"加粗",click:"bold", src:"bold.gif"},
                      	 {index:1,title:"斜体",click:"italic", src:"italic.gif"},
                      	 {index:2,title:"下划线",click:"underline", src:"underline.gif"},
                      	 {index:3,title:"上标",click:"superScript", src:"superscript.gif"},
                      	 {index:4,title:"下标",click:"subScript", src:"subscript.gif"},
                      	 {index:5,title:"删除线",click:"strikeThrough", src:"strikethrough.gif"},
                      	 {index:6,title:"取消格式",click:"removeFormat", src:"removeformat.gif"},
                      	 {index:7,title:"左对齐",click:"justifyLeft", src:"aleft.gif"},
                      	 {index:8,title:"居中",click:"justifyCenter", src:"center.gif"},
                      	 {index:9,title:"右对齐",click:"justifyRight", src:"aright.gif"},
                      	 {index:10,title:"编号",click:"insertOrderedList", src:"numlist.gif"},
                      	 {index:11,title:"项目符号",click:"insertUnorderedList", src:"bullist.gif"},
                      	 {index:12,title:"减少缩进量",click:"outdent", src:"outdent.gif"},
                      	 {index:13,title:"增加缩进量",click:"indent", src:"indent.gif"},
                      	 {index:14,title:"插入表情",click:"forEmotion", src:"smiley.gif"},
                      	 {index:15,title:"上传文件",click:"oblog_forfile", src:"file.gif"}
                      	]
                      ];
// firefox中需要隐藏的图标
EditorComp.hideIndicesDefault = [[],[4,5,11,12,13,14],[]];

/**
 * 高级文本编辑器构造函数
 * @class 高级文本编辑器
 * @constructor
 * @param{Array} hideBarIndices 一维数组,指定要隐藏的工具条
 * @param{Array} hideImageIndices 二维数组,指定要隐藏的每行的按钮,形式如[[0,1],[],[2]]
 * @param hideBarIndices 需要隐藏的行
 */
function EditorComp(parent, name, left, top, width, height, position,
		hideBarIndices, hideImageIndices, className) {
	this.base = BaseComponent;
	this.base(name, left, top, width, height);
	this.parentOwner = parent;
	this.position = getString(position, "absolute");
	this.className = getString(className, "cms_editor");
	this.imageNode = null;
	this.liNode = null;
	this.hiddenContent = null;
	this.frame = null;
	this.hideBarIndices = hideBarIndices;
	this.hideImageIndices = hideImageIndices;
	this.charset = "UTF-8";
	// 当前模式 0 代码,1 design
	this.mode = 1;
	this.toolbars = new Array;
	this.btDesign = null;
	this.btView = null;
	this.btHtml = null;
	this.filterScript = false;
	// 用来记录当前是否初始化完成。防止iframe多线程操作出问题
	this.initialized = false;
	// 当前编辑器是否可以编辑
	this.disabled = false;
	this.value = "";

	// 在页面上设置当前编辑器对象
	window.currentEditor = this;
	
	// redo栈，当执行undo时，将undo前的信息保存在栈中
	this.redoStack = new Array();
	
	this.create();
};

/**
 * 创建整体显示对象
 * @private
 */
EditorComp.prototype.create = function() {
	var oThis = this;
	this.Div_gen = document.createElement("DIV");
	this.Div_gen.id = this.id;
	// guoweic: modify start 2009-11-10
	this.Div_gen.style.left = this.left + "px";
	this.Div_gen.style.top = this.top + "px";
	if (this.width.toString().indexOf("%") == -1)
		this.Div_gen.style.width = this.width + "px";
	else
		this.Div_gen.style.width = this.width;
	if (this.height.toString().indexOf("%") == -1)
		this.Div_gen.style.height = this.height + "px";
	else
		this.Div_gen.style.height = this.height;
	// guoweic: modify end
	this.Div_gen.style.position = this.position;
	this.Div_gen.className = this.className;
	this.Div_gen.style.overflow = "auto";
	if (this.parentOwner)
		this.placeIn(this.parentOwner);
};

/**
 * 创建编辑器的toolbar,内容区,操作bar
 * @private
 */
EditorComp.prototype.manageSelf = function() {
	this.createToolBars();
	this.createFrame();
	this.initEditor();
	this.createOperateBars();
};

/**
 * @private
 */
EditorComp.prototype.createFrame = function() {
	this.ul = document.createElement("UL");
	// guoweic: modify start 2009-11-12
	var ulHeight = this.Div_gen.offsetHeight
			- (EditorComp.ROW_HEIGHT * (this.hideBarIndices == null ? 3
					: 3 - this.hideBarIndices.length)) - 55;
	// guoweic: modify end
	if (ulHeight < 0)
		ulHeight = 100;
	// guoweic: modify start 2009-11-10
	this.ul.style.height = ulHeight + "px";
	// guoweic: modify end
	this.frame = $ce('iframe');
	this.frame.className = "editor_frame";
	this.frame.frameBorder = 0;
	this.frame.name = this.id + "_composition";
	this.frame.width = "100%";
	this.frame.height = "100%";
	
	window.editorFrameOwner = this.frame;
	this.ul.appendChild(this.frame);
	
	// guoweic: add start 2009-12-18
	// firefox中，输入内容的html高度没有填满整个iframe，很难获得输入焦点，现在做以下修改
	if (!IS_IE) {
		var oThis = this;
		this.ul.onmouseover = function(){
			var editorBody = oThis.frame.contentWindow.document.getElementById("editorBody");
			if (editorBody) {
				editorBody.focus();
			}
		};
		//TODO guoweic
		this.ul.onmousemove = function(e){
			console.log(oThis.ul);
		};
	}
	// guoweic: add end
	
	this.Div_gen.appendChild(this.ul);

	// guoweic: add start 2009-11-12
	this.ul.style.width = this.Div_gen.offsetWidth - 8 + "px";
	// guoweic: add end
	var oThis = this;
	this.Div_gen.onresize = function() {
		var ulHeight = this.offsetHeight
				- (EditorComp.ROW_HEIGHT * (oThis.hideBarIndices == null ? 3
						: 3 - oThis.hideBarIndices.length)) - 40;
		if (ulHeight < 0)
			ulHeight = 100;
		oThis.ul.style.height = ulHeight + "px";
	};
};

/**
 * 创建操作工具条
 * @private
 */
EditorComp.prototype.createOperateBars = function() {
	var oThis = this;
	var ul = document.createElement("UL");
	var li = document.createElement("LI");
	li.style.width = "10px";
	ul.appendChild(li);

	li = document.createElement("li");
	li.className = "tabon";
	li.id = "tabdesign";
	li.onclick = function() {
		if (oThis.mode != 1) {
			oThis.setMode(1);
		}
	};
	this.btDesign = li;

	var img = document.createElement("img");
	img.src = window.themePath + "/images/editor/mode.design.gif";
	img.width = "20px";
	img.height = "20px";
	li.appendChild(img);
	li.appendChild(document.createTextNode(" 设计"));
	ul.appendChild(li);
	// guoweic: modify start 2009-11-10
	if (IS_IE)
		ul.appendChild(li.cloneNode());
	// guoweic: modify end

	li = document.createElement("li");
	li.className = "taboff";
	li.id = "tabview";
	li.onclick = function() {
		if (oThis.mode != 2) {
			oThis.preView();
		}
	};
	this.btView = li;

	var img = document.createElement("img");
	img.src = window.themePath + "/images/editor/mode.view.gif";
	img.width = "20px";
	img.height = "20px";
	li.appendChild(img);
	li.appendChild(document.createTextNode(" 预览"));
	ul.appendChild(li);
	// guoweic: modify start 2009-11-10
	if (IS_IE)
		ul.appendChild(li.cloneNode());
	// guoweic: modify end

	li = document.createElement("li");
	li.className = "taboff";
	li.id = "tabhtml";
	li.onclick = function() {
		if (oThis.mode != 3) {
			oThis.setMode(3);
		}
	};
	this.btHtml = li;

	/*
	 * var img = document.createElement("img"); img.src =
	 * "/lfw/frame/themes/images/mode.html.gif"; img.width = "20px"; img.height =
	 * "20px"; li.appendChild(img); li.appendChild(document.createTextNode("
	 * 源码")); ul.appendChild(li);
	 */

	this.Div_gen.appendChild(ul);

	// guoweic: add start 2009-11-12
	ul.style.width = this.Div_gen.offsetWidth - 8 + "px";
	// guoweic: add end

};

/**
 * 初始化编辑器
 * @private
 */
EditorComp.prototype.initEditor = function() {
	var oThis = this;
	window.PostType = 1;
	window.oblog_Composition = null;
	if (IS_IE) {
		for ( var i = 0; i < document.frames.length; i++) {
			if (document.frames[i].name = (this.id + "_composition")) {
				this.editorWindow = document.frames[i];
				break;
			}
		}
	} else
		this.editorWindow = this.frame.contentWindow;

	this.editorDoc = this.editorWindow.document;
	// 将frame实例放入window变量
	window.$editorWindow = this.editorWindow;
	// guoweic: modify firefox中iframe使用和IE有区别 start 2009-11-11
	// firefox中EditorComp.editorWindow后面不能直接跟.document，必须用时再写
	EditorComp.editorWindow = this.editorWindow;
	EditorComp.editorWindow.document.designMode = "On";
	// guoweic: modify end
	setTimeout("EditorComp.initIFrame()", 50);
	EditorComp.nowDoc = this.editorDoc;
	EditorComp.defaultValue = this.value;
	EditorComp.charset = this.charset;
	EditorComp.mode = this.mode;

	//TODO 绑定blur事件（事件方法中对this的取值有问题，只能用window.currentEditor解决）
	if (IS_IE) {
		this.frame.attachEvent("onblur", this.onblur);
	} else {
		this.frame.contentWindow.addEventListener("blur", this.onblur, false);
	}
};

/**
 * 初始化编辑页面
 * @private
 */
EditorComp.initIFrame = function() {
	// guoweic: modify firefox中iframe使用和IE有区别 start 2009-11-11
	// firefox中EditorComp.editorWindow后面不能直接跟.document，必须用时再写
	var win = EditorComp.editorWindow;
	win.document.open();
	win.document.write('<!DOCTYPE html PUBLIC "-/');
	win.document.write('/W3C/');
	win.document.write('/DTD XHTML 1.0 Strict/');
	win.document.write('/EN" "http:/');
	win.document.write('/www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><html xmlns="http:/');
	win.document.write('/www.w3.org/1999/xhtml"><head>');
	win.document.write("</head><body id='editorBody'>" + EditorComp.defaultValue + "</body>");
	win.document.write("</html>");
	win.document.close();
	win.document.body.contentEditable = "true";
	win.document.charset = EditorComp.charset;
	EditorComp.setEditorStyle(win, EditorComp.mode);
	// guoweic: modify end
	EditorComp.initialized = true;
};

/**
 * 设置编辑类型
 * @private
 */
EditorComp.setEditorStyle = function(win, mode) {
	var bd = win.document.body;
	bd.style.backgroundColor = "white";
	if (mode == 2) {
		bd.style.fontFamily = "Arial";
		bd.style.fontSize = "10pt";
	} else {
		bd.style.fontFamily = "Arial";
		bd.style.fontSize = "10.5pt";
	}
	bd.style.scrollbar3dLightColor = '#D4D0C8';
	bd.style.scrollbarArrowColor = '#000000';
	bd.style.scrollbarBaseColor = '#D4D0C8';
	bd.style.scrollbarDarkShadowColor = '#D4D0C8';
	bd.style.scrollbarFaceColor = '#D4D0C8';
	bd.style.scrollbarHighlightColor = '#808080';
	bd.style.scrollbarShadowColor = '#808080';
	bd.style.scrollbarTrackColor = '#D4D0C8';
};

/**
 * 创建toolbars
 * @private
 */
EditorComp.prototype.createToolBars = function() {
	for ( var i = 0; i < 3; i++) {
		if (this.hideBarIndices != null && this.hideBarIndices.length > 0
				&& this.hideBarIndices.indexOf(i) != -1)
			continue;
		// 创建工具条
		var toolbar = this.createToolBar(i);
		this.toolbars[i] = toolbar;
		this.Div_gen.appendChild(toolbar);
		var images = EditorComp.ACTION_LIST[i];
		var length = (i == 0) ? images.length + 3 : images.length;
		for ( var j = 0; j < length; j++) {
			// 获取此toobar需要隐藏的元素数组
			var hideIndices = null;
			if (this.hideImageIndices != null
					&& this.hideImageIndices.length > 0)
				hideIndices = this.hideImageIndices[i];
			if (hideIndices != null && hideIndices.length > 0
					&& images[j] != null
					&& hideIndices.indexOf(images[j].index) != -1)
				continue;
			// firefox下需要隐藏一些图标
			if (!IS_IE) {
				var hideIndicesDefault = null;
				if (EditorComp.hideIndicesDefault != null
						&& EditorComp.hideIndicesDefault.length > 0)
					hideIndicesDefault = EditorComp.hideIndicesDefault[i];
				if (hideIndicesDefault != null && hideIndicesDefault.length > 0
						&& images[j] != null
						&& hideIndicesDefault.indexOf(images[j].index) != -1)
					continue;
			}
			if (i == 0) {
				if (j < 3) {
					var isShow = hideIndices == null || hideIndices.length == 0 || (hideIndices.length > 0 && hideIndices.indexOf(j) == -1);
					var isDefaultShow = hideIndicesDefault == null || hideIndicesDefault.length == 0 || (hideIndicesDefault.length > 0 && hideIndicesDefault.indexOf(j) == -1);
					if (IS_IE) {
						if (isShow)
							this.createComboComp(j);
					} else {
						if (isShow && isDefaultShow)
							this.createComboComp(j);
					}
				} else {
					var li = this.cloneLi(images[j - 3].title,
							images[j - 3].click, 0);
					var image = this.cloneImage(window.themePath + "/images/editor/" + images[j - 3].src);
					image.style[ATTRFLOAT] = "left";
					li.appendChild(image);
					toolbar.appendChild(li);
				}
			} else {
				var li = this.cloneLi(images[j].title, images[j].click, 1);
				var image = this.cloneImage(window.themePath + "/images/editor/" + images[j].src);
				li.appendChild(image);
				toolbar.appendChild(li);
			}
		}
		
		// guoweic: add start 2009-11-12
		toolbar.style.width = this.Div_gen.offsetWidth - 8 + "px";
		// guoweic: add end
	}
};

/**
 * 创建下拉框控件
 * @private
 */
EditorComp.prototype.createComboComp = function(index) {
	var oThis = this;
	// guoweic: modify firefox不支持SELECT.add()方法，只支持SELECT.OPTIONS.add() start 2009-11-10
	if (index == 0) {
		this.formatComb = document.createElement("select");
		this.formatComb.style[ATTRFLOAT] = "left";
		this.formatComb.style.marginTop = "3px";
		this.formatComb.style.marginLeft = "6px";
		this.formatComb.id = "formatComb";
		this.toolbars[0].appendChild(this.formatComb);
		this.formatComb.options.add(new Option("段落格式", ""));
		this.formatComb.options.add(new Option("普通格式", "<P>"));
		for ( var i = 0; i < 7; i++) {
			this.formatComb.options.add(new Option("标题" + (i + 1), "<H" + (i + 1) + ">"));
		}
		this.formatComb.options.add(new Option("已编排格式", "<PRE>"));
		this.formatComb.options.add(new Option("地址", "<ADDRESS>"));
		this.formatComb.onchange = function() {
			oThis.doSelectClick('FormatBlock', oThis.formatComb);
		};
	} else if (index == 1) {
		this.fontComb = document.createElement("select");
		this.fontComb.style[ATTRFLOAT] = "left";
		this.fontComb.style.marginTop = "3px";
		this.fontComb.style.marginLeft = "6px";
		this.fontComb.id = "fontComb";
		this.toolbars[0].appendChild(this.fontComb);
		this.fontComb.options.add(new Option("字体", ""));
		var fontArr = [ [ "宋体", "宋体" ], [ "黑体", "黑体" ], [ "楷体", "楷体_GB2312" ],
				[ "仿宋", "仿宋_GB2312" ], [ "隶书", "隶书" ], [ "幼圆", "幼圆" ],
				[ "新宋体", "新宋体" ], [ "细明体", "细明体" ], [ "Arial", "Arial" ],
				[ "Courier", "Courier" ], [ "System", "System" ] ];
		this.fontComb.options.add(new Option("普通格式", "<P>"));
		for ( var i = 0; i < fontArr.length; i++) {
			this.fontComb.options.add(new Option(fontArr[i][0], fontArr[i][1]));
		}
		this.fontComb.onchange = function() {
			oThis.formatText('fontname',
					oThis.fontComb[oThis.fontComb.selectedIndex].value);
		};
	} else if (index == 2) {
		this.sizeComb = document.createElement("select");
		this.sizeComb.style[ATTRFLOAT] = "left";
		this.sizeComb.style.marginTop = "3px";
		this.sizeComb.style.marginLeft = "6px";
		// guoweic: modify start 2009-12-22
		if (!IS_IE)
			this.sizeComb.style.marginRight = "20px";
		// guoweic: modify end
		this.sizeComb.id = "sizeComb";
		this.toolbars[0].appendChild(this.sizeComb);
		this.sizeComb.options.add(new Option("字号", ""));
		for ( var i = 1; i <= 7; i++) {
			this.sizeComb.options.add(new Option(i, i));
		}
		this.sizeComb.onmousedown = function() {

		};
		this.sizeComb.onchange = function() {
			oThis.formatText('fontsize',
					oThis.sizeComb[oThis.sizeComb.selectedIndex].value);
			stopEvent(EventUtil.getEvent());
		};
	}
	//guoweic: 去掉缩放功能
//	else if (index == 3) {
//		var zoomArr = [ 50, 75, 100, 125, 150, 175, 200 ];
//		this.zoomComb = document.createElement("select");
//		this.zoomComb.style[ATTRFLOAT] = "left";
//		this.zoomComb.style.marginTop = "3px";
//		this.zoomComb.style.marginLeft = "6px";
//		// guoweic: modify start 2009-11-12
//		if (!IS_IE)
//			this.zoomComb.style.marginRight = "20px";
//		// guoweic: modify end
//		this.zoomComb.id = "zoomComb";
//		this.toolbars[0].appendChild(this.zoomComb);
//		this.zoomComb.options.add(new Option("缩放", ""));
//		for ( var i = 1; i <= zoomArr.length; i++) {
//			this.zoomComb.options.add(new Option(zoomArr[i - 1] + "%", zoomArr[i - 1]));
//		}
//		this.zoomComb.onchange = function() {
//			oThis.doZoom(oThis.zoomComb[oThis.zoomComb.selectedIndex].value);
//		}
//	}
	// guwoeic: modify end
};

/**
 * 创建工具条
 * @private
 */
EditorComp.prototype.createToolBar = function(index) {
	var toolBar = document.createElement("UL");
	toolBar.id = this.id + "ExtToolbar" + index;
	// guoweic: modify start 2009-11-10
	toolBar.style.height = EditorComp.ROW_HEIGHT + "px";
	// guoweic: modify end
	return toolBar;
};

/**
 * 复制图片
 * @private
 */
EditorComp.prototype.cloneImage = function(src) {
	if (this.imageNode == null) {
		this.imageNode = document.createElement("IMG");
		this.imageNode.className = "toolimage";
	}
	var node = this.imageNode.cloneNode(true);
	node.src = src;
	return node;
};

/**
 * 复制li
 * @private
 */
EditorComp.prototype.cloneLi = function(title, func, type) {
	var oThis = this;
	if (this.liNode == null) {
		this.liNode = document.createElement("LI");
		this.liNode.style.position = "relative";
		this.liNode.style[ATTRFLOAT] = "left";
		this.liNode.className = "edit_bt_out";
	}
	var node = this.liNode.cloneNode(true);
	if (type == 0)
		node.style.left = 46;
	node.onmouseover = EditorComp.Edit_bt_over;
	node.onmouseout = EditorComp.Edit_bt_out;
	node.title = title;
	if (this[func]) {
		node.onmousedown = function(e) {
			if (oThis.disabled)
				return;
			//TODO
			eval("oThis." + func + "()");
			e = EventUtil.getEvent();
			stopDefault(e);
			// 删除事件对象（用于清除依赖关系）
			clearEventSimply(e);
		};
	}
	return node;
};

/**
 * 设置编辑按钮鼠标移入样式
 * @private
 */
EditorComp.Edit_bt_over = function() {
	this.className = "edit_bt_over";
};

/**
 * 设置编辑按钮鼠标移出样式
 * @private
 */
EditorComp.Edit_bt_out = function() {
	this.className = "edit_bt_out";
};

/**
 * 设置模式
 * @private
 */
EditorComp.prototype.setMode = function(mode) {
	EditorComp.setEditorStyle(this.editorWindow, mode);
	var cont;
	// guoweic: modify start 2009-11-24
	var win = this.editorWindow;
	switch (mode) {
	case 1:
		for ( var i = 0; i < this.toolbars.length; i++) {
			if (this.toolbars[i] != null)
				this.toolbars[i].style.display = "";
		}
		if (this.btHtml.className == "tabon") {
			if (IS_IE) {
				cont = win.document.body.innerText;
				cont = EditorComp.correctUrl(cont);
				if (this.filterScript)
					cont = EditorComp.filterScript(cont);
				win.document.body.innerHTML = "<a>　</a>" + cont;
			} else {
				var html = win.document.body.ownerDocument.createRange();
				html.selectNodeContents(win.document.body);
				win.document.body.innerHTML = html.toString();
			}
		}
		break;
	case 2:
		for ( var i = 0; i < this.toolbars.length; i++) {
			if (this.toolbars[i] != null)
				this.toolbars[i].style.display = "none";
		}
		this.cleanHtml();
		cont = win.document.body.innerHTML;
		cont = EditorComp.replaceCode(win.document.body.innerHTML, "<a>　</a>", "");
		cont = EditorComp.correctUrl(cont);
		if (this.filterScript) {
			cont = EditorComp.filterScript(cont);
		}
		if (IS_IE) {// IE
			win.document.body.innerText = cont;
		} else { // Nc
			var html = document.createTextNode(cont);
			win.document.body.innerHTML = "";
			win.document.body.appendChild(html);
		}
		break;

	case 3:
		for ( var i = 0; i < this.toolbars.length; i++)
			this.toolbars[i].style.display = "none";
		if (this.btHtml.className == "tabon") {
			if (IS_IE) {
				cont = win.document.body.innerText;
				cont = EditorComp.correctUrl(cont);
				if (this.filterScript)
					cont = EditorComp.filterScript(cont);
				win.document.body.innerHTML = cont;
			} else {
				var html = win.document.body.ownerDocument.createRange();
				html.selectNodeContents(win.document.body);
				win.document.body.innerHTML = html.toString();
			}
		}
		break;
	}
	// guoweic: modify end
	this.setTab(mode);
	this.mode = mode;
};

/**
 * 设置tab
 * @private
 */
EditorComp.prototype.setTab = function(n) {
	// html和design按钮的样式更改
	if (n == 1) {
		this.btHtml.className = "taboff";
		this.btDesign.className = "tabon";
	} else if (n == 2) {
		this.btHtml.className = "taboff";
		this.btDesign.className = "taboff";
	} else if (n == 3) {
		this.btHtml.className = "tabon";
		this.btDesign.className = "taboff";
	}
};

/**
 * 清除内容
 * @private
 */
EditorComp.prototype.cleanHtml = function() {
	// guoweic: modify start 2009-11-24
	var win = this.editorWindow;
	if (IS_IE) {
		var fonts = win.document.body.all.tags("FONT");
	} else {
		var fonts = win.document.getElementsByTagName("FONT");
	}
	// guoweic: modify end
	var curr;
	for ( var i = fonts.length - 1; i >= 0; i--) {
		curr = fonts[i];
		if (curr.style.backgroundColor == "#ffffff")
			curr.outerHTML = curr.innerHTML;
	}
};

/**
 * 替换编码
 * @private
 */
EditorComp.replaceCode = function(s, a, b, i) {
	// s原字串，a要换掉pattern，b换成字串，i是否区分大小写
	a = a.replace("?", "\\?");
	if (!i)
		var r = new RegExp(a, "gi");
	else
		var r = new RegExp(a, "g");
	return s.replace(r, b);
};

/**
 * 纠正URL编码
 * @private
 */
EditorComp.correctUrl = function(cont) {
	var regExp;
	var url = location.href.substring(0, location.href.lastIndexOf("/") + 1);
	cont = EditorComp.replaceCode(cont, location.href + "#", "#");
	cont = EditorComp.replaceCode(cont, url, "");
	cont = EditorComp.replaceCode(cont, "<a>???</a>", "");
	return cont;
};

/**
 * 过滤脚本
 * @private
 */
EditorComp.filterScript = function(content) {
	content = EditorComp.replaceCode(content, 'javascript:',
			'<b>javascript</b> :');
	var RegExp = /<script[^>]*>(.*)<\/script>/gi;
	content = content
			.replace(RegExp, "<div class=HtmlCode>&lt;!-- Script 代码开始 --&gt;<br>$1<br>&lt;!-- Script 代码结束 --&gt;</div>");
	RegExp = /<P>&nbsp;<\/P>/gi;
	content = content.replace(RegExp, "");
	return content;
};

/**
 * 预览
 */
EditorComp.prototype.preView = function() {
	// guoweic: modify start 2009-11-11
	var win = this.editorWindow;
	if (this.mode == 2) {
		cont = win.document.body.innerText;
	} else {
		cont = win.document.body.innerHTML;
	}
	// guoweic: modify end
	cont = EditorComp.correctUrl(cont);
	bodyTag = "<html><head><style type=text/css>.quote{margin:5px 20px;border:1px solid #CCCCCC;padding:5px; background:#F3F3F3 }\nbody{boder:0px}.HtmlCode{margin:5px 20px;border:1px solid #CCCCCC;padding:5px;background:#FDFDDF;font-size:14px;font-family:Tahoma;font-style : oblique;line-height : normal ;font-weight:bold;}\nbody{boder:0px}</style></head><BODY bgcolor=\"#FFFFFF\" >";
	if (this.filterScript)
		cont = EditorComp.filterScript(cont);
	cont = EditorComp
			.replaceCode(
					cont,
					"\\[dvnews_ad]",
					"<img src='images/images/pic_ad.jpg' vspace=10 hspace=10 align=left border=1 title='Advertising'>");
	cont = EditorComp
			.replaceCode(
					cont,
					"\\[dvnews_page]",
					"<br><br><hr size=2 width=95% align=left>&nbsp; <font color=red face='Tahoma,Arail' size=2><b>Next Page ...</b></font><br><hr size=2 width=95% align=left>");
	preWin = window
			.open(
					'',
					'',
					'left=0,top=0,width=550,height=400,resizable=1,scrollbars=1, status=0, toolbar=0, menubar=0');
	preWin.document.open();
	preWin.document.write(bodyTag);
	preWin.document.write(cont);
	preWin.document.close();
	preWin.document.title = "Preview";
	preWin.document.charset = this.charset;
};

/**
 * 格式化文字
 * @private
 */
EditorComp.prototype.formatText = function(command, option) {
	var codewrite;
	var win = this.editorWindow;
	if (IS_IE) {
		if (option == "removeFormat") {
			command = option;
			option = null;
		}
		this.editorWindow.focus();
		
		// renxh 解决redo不能恢复的问题，创建一redo栈，执行undo时入栈，执行redo时出栈
		if(command == 'undo'){
			
			this.redoStack.push(win.document.body.innerHTML);
			win.document.execCommand(command, false, option);
		}else if(command == 'redo'){
			
			if(this.redoStack.length>0){
				win.document.body.innerHTML = this.redoStack.pop();
			}
			
		}else{
			win.document.execCommand(command, false, option);
		}
		// oblog_pureText = false;
		this.editorWindow.focus();
	} else if (!IS_IE) {
		// guoweic: modify start 2009-12-22
		if (command == 'backcolor') {
			// firefox中的hilitecolor命令即为ie中的backcolor命令
			command = 'hilitecolor';
		} else if (command == 'cut') {
			// 保存选中内容到组件中
			EditorComp.clipBoard = this.getSelectContentStr();
			//TODO guoweic 保存选中内容到剪切板中
			EditorComp.saveToClipBoard(EditorComp.clipBoard);
			win.getSelection().deleteFromDocument();
			return;
		} else if (command == 'copy') {
			EditorComp.clipBoard = this.getSelectContentStr();
			//TODO guoweic 保存选中内容到剪切板中
			EditorComp.saveToClipBoard(EditorComp.clipBoard);
			return;
		} else if (command == 'paste') {
			//TODO guwoeic 获取浏览器剪切板中内容
			var clipBoardData = EditorComp.getClipBoardData();
			// 获取组件剪切板中内容
			var clipBoard = EditorComp.clipBoard;
			clipBoard = clipBoard == null ? "" : clipBoard;
			this.oblog_InsertSymbol(clipBoardData == null ? clipBoard : clipBoardData);
			
			//this.oblog_InsertSymbol(EditorComp.clipBoard == null ? "" : EditorComp.clipBoard);
			return;
		}
		win.document.execCommand(command, false, option);
		oblog_pureText = false;
		this.editorWindow.focus();
		// guoweic: modify end
	}
};

/**
 * 获取选中区域内容字符串（firefox使用）
 * @author guoweic
 * @private
 */
EditorComp.prototype.getSelectContentStr = function() {
	var win = this.editorWindow;
	var fragmentNodes = win.getSelection().getRangeAt(0).cloneContents().childNodes;
	var str = "";
	for (var i = 0, n = fragmentNodes.length; i < n; i++) {
		if (fragmentNodes[i].nodeType == 3)
			str += fragmentNodes[i].textContent;
		else
			str += fragmentNodes[i].innerHTML;
	}
	return str;
};

/**
 * 将内容复制到剪切板中（firefox使用）
 * @author guoweic
 * @private
 */
EditorComp.saveToClipBoard = function(text) {
	if (window.netscape){
        //alert(typeof(netscape));
        try {
            netscape.security.PrivilegeManager.enablePrivilege('UniversalXPConnect');
        } catch (e) {
            alert("您的firefox安全限制限制您进行剪贴板操作，请打开about:config将signed.applets.codebase_principal_support设置为true'之后重试");
            //Logger.error("您的firefox安全限制限制您进行剪贴板操作，请打开about:config将signed.applets.codebase_principal_support设置为true'之后重试");
            return;
        }
        var clip = Components.classes['@mozilla.org/widget/clipboard;1'].createInstance(Components.interfaces.nsIClipboard);
        if (!clip) return;
        var trans = Components.classes['@mozilla.org/widget/transferable;1'].createInstance(Components.interfaces.nsITransferable);
        if (!trans) return;
        trans.addDataFlavor('text/unicode');
        var str = new Object();
        var len = new Object();
        var str = Components.classes["@mozilla.org/supports-string;1"].createInstance(Components.interfaces.nsISupportsString);   
        var copytext = text;
        str.data = copytext;
        trans.setTransferData("text/unicode", str, copytext.length*2);   
        var clipid = Components.interfaces.nsIClipboard;
        if (!clip) return false;
        clip.setData(trans, null, clipid.kGlobalClipboard);
    }
};

/**
 * 获取剪切板中内容（firefox使用）
 * @author guoweic
 * @private
 */
EditorComp.getClipBoardData = function() {
	if (window.netscape) {
		try {
			netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
			var clip = Components.classes["@mozilla.org/widget/clipboard;1"].createInstance(Components.interfaces.nsIClipboard);
			if (!clip) {
				return;
			}
			var trans = Components.classes["@mozilla.org/widget/transferable;1"].createInstance(Components.interfaces.nsITransferable);
			if (!trans) {
				return;
			}
			trans.addDataFlavor("text/unicode");
			clip.getData(trans, clip.kGlobalClipboard);
			var str = new Object();
			var len = new Object();
			trans.getTransferData("text/unicode", str, len);
		} catch (e) {
			alert("您的firefox安全限制限制您进行剪贴板操作，请打开'about:config'将signed.applets.codebase_principal_support'设置为true'之后重试，相对路径为firefox根目录/greprefs/all.js");
			//Logger.error("您的firefox安全限制限制您进行剪贴板操作，请打开'about:config'将signed.applets.codebase_principal_support'设置为true'之后重试，相对路径为firefox根目录/greprefs/all.js");
			return null;
		} 
		if (str) { 
			if (Components.interfaces.nsISupportsWString) { 
				str = str.value.QueryInterface(Components.interfaces.nsISupportsWString);
			} else {
				if (Components.interfaces.nsISupportsString) {
					str = str.value.QueryInterface(Components.interfaces.nsISupportsString);
				} else {
					str = null;
				}
			}
		}
		if (str) {
			return (str.data.substring(0, len.value / 2));
		}
	}
	return null;
};

/**
 * @private
 */
EditorComp.prototype.doZoom = function(size) {
	// guoweic: modify firefox中iframe使用和IE有区别 start 2009-11-12
	if (size != null || size != "") {
		var win = this.editorWindow;
		if (IS_IE) {
			var z = win.document.body.runtimeStyle;
			z.zoom = size + "%";
		} else if (!IS_IE) {
			var z = win.document.body.style;
			//TODO guoweic 不好使！
			z.mozTransform = "scale(" + parseFloat(size/100) + ")";
		}
	}
	// guoweic: modify end
};

/**
 * @private
 */
EditorComp.prototype.doSelectClick = function(str, el) {
	var Index = el.selectedIndex;
	if (Index != 0) {
		el.selectedIndex = Index;
		this.formatText(str, el.options[Index].value);
	}
};

/**
 * 显示图片上传对话框
 * guoweic: modify 2009-11-13
EditorComp.prototype.oblog_forimg = function() {
	//TODO guoweic
	var arr = showModalDialog(window.baseGlobalPath
			+ "/frame/editor/files/img.jsp?identifier="
			+ window.sys_identifier, window,
			"dialogWidth:350px; dialogHeight:250px; status:0; help:0");
	
	this.editorWindow.focus();
	if (arr != null) {
		this.oblog_InsertSymbol(arr[1]);
		this.editorWindow.focus();
	} else
		this.editorWindow.focus();
};
 */

/**
 * 显示图片上传对话框
 * @private
 */
EditorComp.prototype.oblog_forimg = function() {
//	// 设置当前编辑器，在回调函数中使用
//	window.currentEditor = this;
	var url = "/core/file.jsp?pageId=file&method=afterImgSelected";
	if (window.billitem != null)
		url += "&billitem=" + window.billitem;
	showCommonDialog(window.globalPath + url,
			"", "450px", "450px", null);
};

/**
 * 选择图片后（文件上传）回调函数
 * @private
 */
function afterImgSelected(filePk, fileName) {
	// 文件保存路径
	var dir = window.globalPath + "/pt/file/down?id=" + filePk;
	var arr = "<img src='" + dir + "'></img>"
	if (window.currentEditor != null) {
		// 当前编辑器对象
		var oThis = window.currentEditor;
		oThis.editorWindow.focus();
		if (arr != null)
			oThis.oblog_InsertSymbol(arr);
		oThis.editorWindow.focus();
	}
};

/**
 * 该方法已不用 guoweic
 * @private
 */
EditorComp.prototype.oblog_UserDialog = function(what) {
	/*
	 * if (!oblog_validateMode()) return; var doc = window.editorDoc;
	 * editorWindow.focus(); if (what == "CreateLink") { if (!IS_IE) {
	 * insertLink = prompt("????????????????????????????????????", "http://");
	 * if ((insertLink != null) && (insertLink != "") && (insertLink !=
	 * "undefined")) { doc.execCommand('CreateLink', false, insertLink); } else {
	 * doc.execCommand('unlink', false, null); } } else { doc.execCommand(what,
	 * true, null); } } if(what == "InsertImage"){ imagePath =
	 * prompt('????????????????????????????????????', 'http://'); if ((imagePath !=
	 * null) && (imagePath != "")) { editorFrameCommand('InsertImage', false,
	 * imagePath); } doc.body.innerHTML =
	 * (doc.body.innerHTML).replace("src=\"file://","src=\""); } oblog_pureText =
	 * false; editorWindow.focus();
	 */
};


/**
 * 显示文件上传对话框
EditorComp.prototype.oblog_forfile = function() {
	var oThis = this;
//	if (IS_IE) {
		var arr = showCommonDialog(window.baseGlobalPath
				+ "/frame/editor/files/file.jsp?identifier="
				+ window.sys_identifier, "", "350px", "250px", null);
		this.editorWindow.focus();
		if (arr != null) {
			this.oblog_InsertSymbol(arr[0]);
			this.editorWindow.focus();
			// 回调方法,用户可以在此方法中做事
			if (window.afterUploadSuccess) {
				window.afterUploadSuccess(arr[1]);
			}
		} else
			this.editorWindow.focus();
//	}
};
 */

/**
 * 显示文件上传对话框
 * @private
 */
EditorComp.prototype.oblog_forfile = function() {
//	// 设置当前编辑器，在回调函数中使用
//	window.currentEditor = this;

	var url = "/core/file.jsp?pageId=file&method=afterFileUpload";
	if (window.billitem != null)
		url += "&billitem=" + window.billitem;
	showCommonDialog(window.globalPath + url, "", "450px", "450px", null);
};

/**
 * 文件上传回调函数
 * @private
 */
function afterFileUpload(filePk, fileName) {
	// 文件保存路径
	var dir = window.globalPath + "/pt/file/down?id=" + filePk;
	var arr = "<a href='" + dir + "' target='_blank'>" + fileName + "</a> "
	if (window.currentEditor != null) {
		// 当前编辑器对象
		var oThis = window.currentEditor;
		oThis.editorWindow.focus();
		if (arr != null)
			oThis.oblog_InsertSymbol(arr);
		oThis.editorWindow.focus();
	}
};

/**
 * 插入元素
 * @private
 */
//TODO guoweic
EditorComp.insertElement = function(win, elem) {
	var sel = win.getSelection();  // 获取当前selection
	var range = sel.getRangeAt(0);  // 获取selection的第一个range（一般只有一个range）
	sel.removeAllRanges();  // 取消selection所有range
	range.deleteContents();  // 从document中删除当前selection的content
	var container = range.startContainer;  // 获取本地当前的selection
	var pos = range.startOffset;
	range = document.createRange();  // 为新的selection创建新range

	if (container.nodeType == 3 && elem.nodeType == 3) {
		// 如果插入一段textnode, 做optimized的插入
		container.insertData(pos, elem.nodeValue);

		// 将光标放到插入点后
		range.setEnd(container, pos + elem.length);
		range.setStart(container, pos + elem.length);
	} else {
		var afterNode;
		if (container.nodeType == 3) {
			// 当插入一段textnode时，创建两个新的textnodes，将要插入元素放在中间
			var textNode = container;
			container = textNode.parentNode;
			var text = textNode.nodeValue;

			var textBefore = text.substr(0, pos);  // 分隔前的内容
			var textAfter = text.substr(pos);  // 分隔后的内容

			var beforeNode = document.createTextNode(textBefore);
			var afterNode = document.createTextNode(textAfter);

			// 在旧的node前插入3个新的nodes
			container.insertBefore(afterNode, textNode);
			container.insertBefore(elem, afterNode);
			container.insertBefore(beforeNode, elem);

			// 移除旧的node
			container.removeChild(textNode);
		} else {
			// 简单插入node
			afterNode = container.childNodes[pos];
			container.insertBefore(elem, afterNode);
		}
	}
};

/**
 * 插入内容
 * @private
 */
EditorComp.prototype.oblog_InsertSymbol = function(str1) {
	this.editorWindow.focus();
	//TODO guoweic: modify start 2009-11-23
	var oblog_selection = this.oblog_selectRange();
	if (IS_IE)
		oblog_selection.createRange().pasteHTML(str1);
	else {
        var spanElement = document.createElement("span");
        spanElement.innerHTML = str1;
		EditorComp.insertElement(EditorComp.editorWindow, spanElement);
	}
	// guoweic: modify end
};

/**
 * 获取选中范围
 * @private
 */
EditorComp.prototype.oblog_selectRange = function() {
	//TODO guoweic: modify start 2009-11-12
	if (IS_IE) {
		var doc = this.editorDoc;
		var oblog_selection = doc.selection;
	} else {
		var win = EditorComp.editorWindow;
		var oblog_selection = win.getSelection();
	}
	return oblog_selection;
	// guoweic: modify end
	// oblog_RangeType = oblog_selection.type;
};

/**
 * 前景色颜色选择器
 * @private
 */
EditorComp.prototype.foreColor = function() {
	var returnValue = showCommonDialog(window.baseGlobalPath + "/frame/editor/files/selcolor.html",
			"", "300px", "250px", null);
	if (returnValue != null)
		this.formatText('forecolor', returnValue);
	else
		this.editorWindow.focus();
};

/**
 * 字体背景颜色
 * guoweic: modify 2009-11-13
 * @private
 */
EditorComp.prototype.backColor = function() {
	if (!this.oblog_validateMode())
		return;
	var returnValue = showCommonDialog(window.baseGlobalPath + "/frame/editor/files/selcolor.html", 
			"", "300px", "250px", null);
	if (returnValue != null)
		this.formatText('backcolor', returnValue);
	else
		this.editorWindow.focus();
};

/**
 * 插入特殊符号
 * @private
 */
EditorComp.prototype.insertSpecialChar = function() {
	var returnValue = showCommonDialog(window.baseGlobalPath + "/frame/editor/files/specialchar.html", "", "450px", "300px", null);
	if (returnValue != null) {
		this.oblog_InsertSymbol(returnValue);
	}
	this.editorWindow.focus();
};

/**
 * 查找,替换
 * @private
 */
EditorComp.prototype.oblog_replace = function() {
	var arr = showCommonDialog(window.baseGlobalPath + "/frame/editor/files/replace.html", "",
			"300px", "250px", null);
	if (arr != null) {
		var win = this.editorWindow;
		var ss;
		ss = arr.split("*");
		a = ss[0];
		b = ss[1];
		i = ss[2];
		con = win.document.body.innerHTML;
		if (i == 1) {
			con = this.oblog_rCode(con, a, b, true);
		} else {
			con = this.oblog_rCode(con, a, b);
		}
		win.document.body.innerHTML = con;
	} else
		win.focus();
};

/**
 * 清理代码
 * @private
 */
EditorComp.prototype.oblog_CleanCode = function() {
	var win = this.editorWindow;
	this.editorWindow.focus();
	if (IS_IE) {
		// 0bject based cleaning
		var body = win.document.body;
		for ( var index = 0; index < body.all.length; index++) {
			tag = body.all[index];
			tag.removeAttribute("className", "", 0);
			tag.removeAttribute("style", "", 0);
		}
		// Regex based cleaning
		var html = win.document.body.innerHTML;
		html = html.replace(/\<p>/gi, "[$p]");
		html = html.replace(/\<\/p>/gi, "[$\/p]");
		html = html.replace(/\<br>/gi, "[$br]");
		html = html.replace(/\<[^>]*>/g, ""); // /过滤其它所有"<...>"标签
		html = html.replace(/\[\$p\]/gi, "<p>");
		html = html.replace(/\[\$\/p\]/gi, "<\/p>");
		html = html.replace(/\[\$br\]/gi, "<br>");
		win.document.body.innerHTML = html;
	} else {
		var html = win.document.body.ownerDocument.createRange();
		html.selectNodeContents(win.document.body);
		win.document.body.innerHTML = html.toString();
	}
};

/**
 * 全选
 * @private
 */
EditorComp.prototype.selectAll = function() {
	this.formatText('selectAll');
};

/**
 * 剪切
 * @private
 */
EditorComp.prototype.cut = function() {
	this.formatText('cut');
};

/**
 * 复制
 * @private
 */
EditorComp.prototype.copy = function() {
	this.formatText('copy');
};

/**
 * 粘贴
 * @private
 */
EditorComp.prototype.paste = function() {
	this.formatText('paste');
};

/**
 * 撤销
 * @private
 */
EditorComp.prototype.undo = function() {
	this.formatText('undo');
};

/**
 * 重做
 * @private
 */
EditorComp.prototype.redo = function() {
	this.formatText('redo');
};

/**
 * 插入超链接
 * guoweic: modify 2009-11-13
 * @private
 */
EditorComp.prototype.oblog_forlink = function() {
	showCommonDialog(window.baseGlobalPath + "/frame/editor/files/link.htm", "", "400px",
			"180px", "");
};

/**
 * 去掉链接
 * @private
 */
EditorComp.prototype.unlink = function() {
	this.formatText('Unlink');
};

/**
 * 画水平线
 * @private
 */
EditorComp.prototype.drawHr = function() {
	this.formatText('InsertHorizontalRule', '')
};

/**
 * 弹出表格的处理方法
 * @private
 */
EditorComp.prototype.fortable = function() {
	if (!this.oblog_validateMode())
		return;
	this.editorWindow.focus();
	var arr = showCommonDialog(window.baseGlobalPath + "/frame/editor/files/table.htm", window,
			"450px", "350px", "");
	if (arr) {
		this.editorWindow.document.body.innerHTML += arr;
	}
	this.editorWindow.focus();
};

/**
 * 插入表格行
 * @private
 */
EditorComp.prototype.insertTableRow = function() {
	var editor = this.editorWindow;
	var objReference = this.oblog_GetRangeReference(editor);
	objReference = this.oblog_CheckTag(objReference,
			'/^(TABLE)|^(TR)|^(TD)|^(TBODY)/');
	switch (objReference.tagName) {
	case 'TABLE':
		var newTable = objReference.cloneNode(true);
		var newRow = newTable.insertRow();
		for (x = 0; x < newTable.rows[0].cells.length; x++) {
			var newCell = newRow.insertCell();
			newCell.innerHTML = "&nbsp;";
		}
		// TODO:outerHTMl不垮平台
		objReference.outerHTML = newTable.outerHTML;
		break;
	case 'TBODY':
		var newTable = objReference.cloneNode(true);
		var newRow = newTable.insertRow();
		for (x = 0; x < newTable.rows[0].cells.length; x++) {
			var newCell = newRow.insertCell();
			newCell.innerHTML = "&nbsp;";
		}
		objReference.outerHTML = newTable.outerHTML;
		break;
	case 'TR':
		var rowIndex = objReference.rowIndex;
		var parentTable = objReference.parentElement.parentElement;
		var newTable = parentTable.cloneNode(true);
		var newRow = newTable.insertRow(rowIndex + 1);
		for (x = 0; x < newTable.rows[0].cells.length; x++) {
			var newCell = newRow.insertCell();
			newCell.innerHTML = "&nbsp;";
		}
		parentTable.outerHTML = newTable.outerHTML;
		break;
	case 'TD':
		var parentRow = objReference.parentElement;
		var rowIndex = parentRow.rowIndex;
		var cellIndex = objReference.cellIndex;
		var parentTable = objReference.parentElement.parentElement.parentElement;
		var newTable = parentTable.cloneNode(true);
		var newRow = newTable.insertRow(rowIndex + 1);
		for (x = 0; x < newTable.rows[0].cells.length; x++) {
			var newCell = newRow.insertCell();
			if (x == cellIndex)
				newCell.id = 'ura';
			newCell.innerHTML = "&nbsp;";
		}
		parentTable.outerHTML = newTable.outerHTML;
		var r = editor.document.body.createTextRange();
		var item = editor.document.getElementById('ura');
		item.id = '';
		r.moveToElementText(item);
		r.moveStart('character', r.text.length);
		r.select();
		break;
	default:
		return;
	}
};

/**
 * 删除表格行
 * @private
 */
EditorComp.prototype.deleteTableRow = function() {
	var editor = this.editorWindow;
	objReference = this.oblog_GetRangeReference(editor);
	objReference = this.oblog_CheckTag(objReference,
			'/^(TABLE)|^(TR)|^(TD)|^(TBODY)/');
	switch (objReference.tagName) {
	case 'TR':
		var rowIndex = objReference.rowIndex;// Get rowIndex
		var parentTable = objReference.parentElement.parentElement;
		parentTable.deleteRow(rowIndex);
		break;
	case 'TD':
		var cellIndex = objReference.cellIndex;
		var parentRow = objReference.parentElement;// Get Parent Row
		var rowIndex = parentRow.rowIndex;// Get rowIndex
		var parentTable = objReference.parentElement.parentElement.parentElement;
		parentTable.deleteRow(rowIndex);
		if (rowIndex >= parentTable.rows.length)
			rowIndex = parentTable.rows.length - 1;
		if (rowIndex >= 0) {
			var r = editor.document.body.createTextRange();
			r.moveToElementText(parentTable.rows[rowIndex].cells[cellIndex]);
			r.moveStart('character', r.text.length);
			r.select();
		} else
			parentTable.removeNode(true);
		break;
	default:
		return;
	}
};

/**
 * 插入表格列
 * @private
 */
EditorComp.prototype.insertTableColumn = function() {
	var editor = this.editorWindow;
	objReference = this.oblog_GetRangeReference(editor);
	objReference = this.oblog_CheckTag(objReference,
			'/^(TABLE)|^(TR)|^(TD)|^(TBODY)/');
	switch (objReference.tagName) {
	case 'TABLE':// IF a table is selected, it adds a new column on the right
					// hand side of the table.
		var newTable = objReference.cloneNode(true);
		var newCell = null;
		for ( var x = 0; x < newTable.rows.length; x++) {
			newCell = newTable.rows[x].insertCell();
			newCell.innerHTML = "&nbsp;";
		}
		newCell.focus();
		objReference.outerHTML = newTable.outerHTML;
		break;
	case 'TBODY': // IF a table is selected, it adds a new column on the right
					// hand side of the table.
		var newTable = objReference.cloneNode(true);
		var newCell = null
		for ( var x = 0; x < newTable.rows.length; x++){
			newCell = newTable.rows[x].insertCell();
			newCell.innerHTML = "&nbsp;";
		}
		objReference.outerHTML = newTable.outerHTML;
		break;
	case 'TR':// IF a table is selected, it adds a new column on the right
				// hand side of the table.
		objReference = objReference.parentElement.parentElement;
		var newTable = objReference.cloneNode(true);
		var newCell = null;
		for ( var x = 0; x < newTable.rows.length; x++){
			newCell = newTable.rows[x].insertCell();
			newCell.innerHTML = "&nbsp;";
		}
		objReference.outerHTML = newTable.outerHTML;
		break;
	case 'TD':// IF the cursor is in a cell, or a cell is selected, it adds a
				// new column to the right of that cell.
		var cellIndex = objReference.cellIndex;// Get cellIndex
		var rowIndex = objReference.parentElement.rowIndex;
		var parentTable = objReference.parentElement.parentElement.parentElement;
		var newTable = parentTable.cloneNode(true);
		var newCell = null;
		for (x = 0; x < newTable.rows.length; x++) {
			newCell = newTable.rows[x].insertCell(cellIndex + 1);
			if (x == rowIndex)
				newCell.id = 'ura';
			newCell.innerHTML = "&nbsp;";
		}
		parentTable.outerHTML = newTable.outerHTML;
		var r = editor.document.body.createTextRange();
		var item = editor.document.getElementById('ura');
		item.id = '';
		r.moveToElementText(item);
		r.moveStart('character', r.text.length);
		r.select();
		break;
	default:
		return;
	}
};

/**
 * 删除表格列
 * @private
 */
EditorComp.prototype.deleteTableColumn = function() {
	var editor = this.editorWindow;
	objReference = this.oblog_GetRangeReference(editor);
	objReference = this.oblog_CheckTag(objReference,
			'/^(TABLE)|^(TR)|^(TD)|^(TBODY)/');
	switch (objReference.tagName) {
	case 'TD':
		var rowIndex = objReference.parentElement.rowIndex;
		var cellIndex = objReference.cellIndex;// Get cellIndex
		var parentTable = objReference.parentElement.parentElement.parentElement;
		var newTable = parentTable.cloneNode(true);
		if (newTable.rows[0].cells.length == 1) {
			parentTable.removeNode(true);
			return;
		}
		for (x = 0; x < newTable.rows.length; x++) {
			if (typeof(newTable.rows[x].cells[cellIndex]) == 'object')
				newTable.rows[x].deleteCell(cellIndex);
		}
		if (cellIndex >= newTable.rows[0].cells.length)
			cellIndex = newTable.rows[0].cells.length - 1;
		if (cellIndex >= 0)
			newTable.rows[rowIndex].cells[cellIndex].id = 'ura';
		parentTable.outerHTML = newTable.outerHTML;
		if (cellIndex >= 0) {
			var r = editor.document.body.createTextRange();
			var item = editor.document.getElementById('ura');
			item.id = '';
			r.moveToElementText(item);
			r.moveStart('character', r.text.length);
			r.select();
		}
		break;
	default:
		return;
	}
};

/**
 * @private
 */
EditorComp.prototype.oblog_CheckTag = function(item, tagName) {
	if (item.tagName.search(tagName) != -1)
		return item;
	if (item.tagName == 'BODY')
		return false;
	item = item.parentElement;
	return this.oblog_CheckTag(item, tagName);
};

/**
 * @private
 */
EditorComp.prototype.oblog_GetRangeReference = function(editor) {
	editor.focus();
	var doc = this.editorDoc;
	var objReference = null;
	//TODO guoweic 对firefox处理
	var RangeType = doc.selection.type;
	var selectedRange = doc.selection.createRange();

	switch (RangeType) {
	case 'Control':
		if (selectedRange.length > 0)
			objReference = selectedRange.item(0);
		break;
	case 'None':
		objReference = selectedRange.parentElement();
		break;
	case 'Text':
		objReference = selectedRange.parentElement();
		break;
	}
	return objReference;
};

/**
 * 加粗
 * @private
 */
EditorComp.prototype.bold = function() {
	this.formatText('bold', '');
};

/**
 * 斜体
 * @private
 */
EditorComp.prototype.italic = function() {
	this.formatText('italic', '');
};

/**
 * 下划线
 * @private
 */
EditorComp.prototype.underline = function() {
	this.formatText('underline', '');
};

/**
 * 上标
 * @private
 */
EditorComp.prototype.superScript = function() {
	this.formatText('superscript', '');
};

/**
 * 下标
 * @private
 */
EditorComp.prototype.subScript = function() {
	this.formatText('subscript', '');
};

/**
 * 删除线
 * @private
 */
EditorComp.prototype.strikeThrough = function() {
	this.formatText('strikethrough', '');
};

/**
 * 取消格式
 * @private
 */
EditorComp.prototype.removeFormat = function() {
	this.formatText('RemoveFormat', '');
};

/**
 * 左对齐
 * @private
 */
EditorComp.prototype.justifyLeft = function() {
	this.formatText('justifyleft', '');
};

/**
 * 居中
 * @private
 */
EditorComp.prototype.justifyCenter = function() {
	this.formatText('justifycenter', '');
};

/**
 * 居右
 * @private
 */
EditorComp.prototype.justifyRight = function() {
	this.formatText('justifyright', '');
};

/**
 * 编号
 * @private
 */
EditorComp.prototype.insertOrderedList = function() {
	this.formatText('insertorderedlist', '');
};

/**
 * 项目编号
 * @private
 */
EditorComp.prototype.insertUnorderedList = function() {
	this.formatText('insertunorderedlist', '');
};

/**
 * 减少缩进量
 * @private
 */
EditorComp.prototype.outdent = function() {
	this.formatText('outdent', '');
};

/**
 * 增加缩进量
 * @private
 */
EditorComp.prototype.indent = function() {
	this.formatText('indent', '');
};

/**
 * 插入表情
 * @private
 */
EditorComp.prototype.forEmotion = function() {
	var arr = showCommonDialog(window.baseGlobalPath + "/frame/editor/files/emot.htm", window, "500px", "360px", "");
	if (arr != null) {
		this.oblog_InsertSymbol(arr);
	} else
		this.editorWindow.focus();
};

/**
 * @private
 */
EditorComp.prototype.oblog_rCode = function(s, a, b, i) {
	// s原字串,a要换掉pattern,b换成字串,i是否区分大小写
	a = a.replace("?", "\\?");
	if (i == null) {
		var r = new RegExp(a, "gi");
	} else if (i) {
		var r = new RegExp(a, "g");
	} else {
		var r = new RegExp(a, "gi");
	}
	return s.replace(r, b);
};

/**
 * 校验模式
 * @private
 */
EditorComp.prototype.oblog_validateMode = function() {
	if (this.mode != 2)
		return true;
	alert("请取消“查看HTML源代码”选项再使用系统编辑功能或者提交!");
	this.editorWindow.focus();
	return false;
};

/**
 * 设值
 */
EditorComp.prototype.setValue = function(value) {
	if (EditorComp.initialized != null && EditorComp.initialized == true)
		this.initialized = true;
	if (value == null)
		value = "";
	this.value = value;
	if (this.initialized) {
		if (this.editorWindow.document.body != null)
			this.editorWindow.document.body.innerHTML = value;
			// this.editorDoc.designMode = "On";
	} else {
		EditorComp.defaultValue = value;
		this.defaultValue = value;
	}
};

/**
 * 获取editor的内容
 */
EditorComp.prototype.getValue = function() {
	if (this.editorWindow.document.body != null) {
		if (this.editorWindow.document.body.innerHTML == "<P>&nbsp;</P>")
			return "";
		return this.editorWindow.document.body.innerHTML;
	} else {
		return "";
	}
};

/**
 * 设置可编辑状态
 */
EditorComp.prototype.setActive = function(active) {
	var win = this.editorWindow;
	
	if (active) {
		// guoweic add start 2009-11-16
		if (win.document.body)
			win.document.body.contentEditable = "true";
		// guoweic add end
		if (win.document.documentElement) {
			var outerHtml = win.document.documentElement.outerHTML;
			win.document.open();
			if (outerHtml != null)
				win.document.write(outerHtml);
			else
				win.document.write("<body></body>");
		}
		win.document.designMode = "On";
		this.disabled = false;
	} else {
		// guoweic add start 2009-11-16
		if (win.document.body)
			win.document.body.contentEditable = "false";
		// guoweic add end
		if (win.document.documentElement) {
			var outerHtml = win.document.documentElement.outerHTML;
			win.document.open();
			if (outerHtml != null)
				win.document.write(outerHtml);
			else
				win.document.write("<body></body>");
		}
		win.document.designMode = "Off";
		this.disabled = true;
	}
};

/**
 * 用户自定义blur事件
 * @private
 */
EditorComp.prototype.onblur = function(e) {
	var oThis = window.currentEditor;
	var focusEvent = {
			"obj" : oThis,
			"event" : e
		};
	oThis.doEventFunc("onBlur", FocusListener.listenerType, focusEvent);
};

/**
 * 获取对象信息
 * @private
 */
EditorComp.prototype.getContext = function() {
	var context = new Object;
//	context.javaClass = "nc.uap.lfw.core.comp.ctx.EditorContext";
	context.c = "EditorContext";
	context.id = this.id;
	context.enabled = !this.disabled;
	context.value = this.getValue();
	//处理连接符(+,&)丢失问题
	context.value = context.value.replace(/\+/g, "%2B");
	context.value = context.value.replace(/\&/g, "%26");
	return context;
};

/**
 * 设置对象信息
 * @private
 */
EditorComp.prototype.setContext = function(context) {
	if (context.enabled != null)
		this.setActive(context.enabled);
	if (context.readOnly != null)
		this.setActive(!context.readOnly);
	if (context.value != null && context.value != this.getValue())
		this.setValue(context.value);
};
