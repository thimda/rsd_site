positiveFormat
/**
 * @fileoverview �ַ�����ʽ����Ϣ
 * @author licza
 * @version NC6.0
 * 
 */
CurrencyFormatMeta.prototype = new NumberFormatMeta();
CurrencyFormatMeta.prototype.metaType = "CurrencyFormatMeta";
CurrencyFormatMeta.prototype.curSymbol = "";
/**
 * ���췽��
 */
function CurrencyFormatMeta(){
	this.positiveFormat = "$n";	
	this.negativeFormat = "$-n";
};