/** ���ֳ���� */
DateTimeFormatMeta.yyyy = "yyyy";
/** ���ֶ���� */
DateTimeFormatMeta.yy = "yy";
/** Ӣ�ĳ��·� */
DateTimeFormatMeta.MMMM = "MMMM";
/** Ӣ�Ķ��·� */
DateTimeFormatMeta.MMM = "MMM";
/** ���ֳ��·� */
DateTimeFormatMeta.MM = "MM";
/** ���ֶ��·� */
DateTimeFormatMeta.M = "M";
/** ���ֳ����� */
DateTimeFormatMeta.dd = "dd";
/** ���ֶ����� */
DateTimeFormatMeta.d = "d";

DateTimeFormatMeta.h = "h";
DateTimeFormatMeta.hh = "hh";
DateTimeFormatMeta.H = "H";
DateTimeFormatMeta.HH = "HH";
DateTimeFormatMeta.m = "m";
DateTimeFormatMeta.mm = "mm";
DateTimeFormatMeta.s = "s";
DateTimeFormatMeta.ss = "ss";
/** am/pm */
DateTimeFormatMeta.t = "t";

function DateTimeFormatMeta(){
	this.format = "yyyy-M-d h:m:s";
	this.speratorSymbol = "-";
}


function DateFormatMeta(){
	this.format = "yyyy-M-d";
	this.speratorSymbol = "-";
}



NumberFormatMeta.POS_FORMAT_ORIGN = "n";
NumberFormatMeta.NEG_FORMAT_HEAD = "-n";
NumberFormatMeta.NEG_FORMAT_HEAD_SPACE = "- n";
NumberFormatMeta.NEG_FORMAT_TAIL = "n-";
NumberFormatMeta.NEG_FORMAT_TAIL_SPACE = "n -";
NumberFormatMeta.NEG_FORMAT_BRACKET = "(n)";
function NumberFormatMeta(){
	/** �Ƿ������� */
	this.isNegRed = false;
	this.isMarkEnable = false;
	this.markSymbol = ",";
	this.pointSymbol = ".";
	this.positiveFormat = POS_FORMAT_ORIGN;
	this.negativeFormat = NEG_FORMAT_HEAD;
}
