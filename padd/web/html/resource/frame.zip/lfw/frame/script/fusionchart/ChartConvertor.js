/**
 * 图表数据模型转换器
 * @author guoweic
 */
function ChartModelConvertor(dataset, config) {
	this.dataset = dataset;
	this.config = config;
};

/**
 * 转换
 */
ChartModelConvertor.prototype.convert = function() {
	// 图表显示系列类型
	var seriesType = this.config.seriesType;
	// 分组列
	var groupColumn = this.config.groupColumn;
	// 分组列图表显示名称
	var groupName = this.config.groupName;
	// 统计列
	var seriesColumns = this.config.seriesColumns;
	// 统计列图表显示名称
	var seriesNames = this.config.seriesNames;
	
	// 将dataset数据分组统计计算
	var groupedDatas = this.calculateDatas(groupColumn, seriesColumns);
	// 转换为图表模型
	var model = this.convertToModel(seriesType, groupedDatas, seriesNames);
	
	return model;
};

/**
 * 将dataset数据分组统计计算
 */
ChartModelConvertor.prototype.calculateDatas = function(groupColumn, seriesColumns) {
	// ds所有行
	var rows = this.dataset.getRows();
	// 转换后的数据集合
	var groupedDatas = new Array;
	// 分组信息对象数组
	var categorys = new Array;
	groupedDatas.push(categorys);
	for (var i = 0, n = seriesColumns.length; i < n; i++) {
		groupedDatas.push(new Array);
	}
	// 分组列索引
	var categoryIndex = this.dataset.nameToIndex(groupColumn);
	// 分组统计计算
	for (var i = 0, n = rows.length; i < n; i++) {
		var row = rows[i];
		categoryValue = rows[i].getCellValue(categoryIndex);
		var index = categorys.indexOf(categoryValue);
		if (index == -1) {
			categorys.push(categoryValue);
			for (var j = 0, m = seriesColumns.length; j < m; j++) {
				var seriesCol = groupedDatas[j + 1];
				var seriesValue = rows[i].getCellValue(this.dataset.nameToIndex(seriesColumns[j]));
				seriesValue = seriesValue == null ? 0 : parseFloat(seriesValue);
				seriesCol.push(seriesValue);
			}
		}
		else {
			for (var j = 0, m = seriesColumns.length; j < m; j++) {
				var seriesCol = groupedDatas[j + 1];
				var seriesValue = rows[i].getCellValue(this.dataset.nameToIndex(seriesColumns[j]));
				seriesValue = seriesValue == null ? 0 : parseFloat(seriesValue);
				seriesCol[index] = seriesCol[index] + seriesValue;
			}
		}
	}
	return groupedDatas;
};

/**
 * 转换为图表模型
 */
ChartModelConvertor.prototype.convertToModel = function(seriesType, groupedDatas, seriesNames) {
	var model = new ChartModel(this.config);
	var categorys = groupedDatas[0];
	// 构建图表模型数据内容
	for (var i = 0, n = (groupedDatas.length - 1); i < n; i ++) {
		var chartDataArray = groupedDatas[i + 1];
		var chartDS = new ChartDataset();
		chartDS.seriesName = seriesNames[i];
		//TODO
//		chartDS.showValues = "0";
		
		
		for (var j = 0, m = chartDataArray.length; j < m; j ++) {
			var set = new ChartSet();
			if (seriesType == ChartConfig.SINGLE_SERIES)
				set.label = categorys[j];
			set.value = chartDataArray[j];
			//TODO
//			set.toolTip = null;
//			set.link = null;
//			set.showLable = "1";
			chartDS.addSet(set);
		}
		model.addChartDataset(chartDS);
	}
	if (seriesType == ChartConfig.MULTI_SERIES) {  // 多系列图形
		// 构建多系列图形的分组信息数据内容
		for (var i = 0, n = categorys.length; i < n; i++) {
			var cate = new Category();
			cate.label = categorys[i];
			model.addCategory(cate);
		}
	}
	return model;
};


//function Bar3DModelConvertor(dataset, config) {
//	this.dataset = dataset;
//	this.config = config;
//}
//
//Bar3DModelConvertor.prototype.convert = function() {
//	var categoryColumn = "year";
//	var seriesName = "city";
//	var valueName = "salary";
//	var rows = this.dataset.getRows();
//	var model = new ChartModel();
//	if(rows != null){
//		var map = new Object;
//		var yearIndex = this.dataset.nameToIndex(categoryColumn);
//		for(var i = 0; i < rows.length; i ++){
//			var value = rows[i].getCellValue(yearIndex);
//			if(map[value] == null)
//				map[value] = new Array;
//		}
//		for(var i in map){
//			var cate = new Category();
//			cate.label = i;
//			model.addCategory(cate);
//		}
//		
//		var cityIndex = this.dataset.nameToIndex(seriesName);
//		var valueIndex = this.dataset.nameToIndex(valueName);
//		var seriesMap = new Object;
//		for(var i = 0; i < rows.length; i ++){
//			var city = rows[i].getCellValue(cityIndex);
//			var value = rows[i].getCellValue(valueIndex);
//			var year = rows[i].getCellValue(yearIndex);
//			if(seriesMap[city] == null){
//				seriesMap[city] = new Object;
//			}
//			if(seriesMap[city][year] == null)
//				seriesMap[city][year] = 0;
//			seriesMap[city][year] += parseFloat(value);
//		}
//		
//		for(var i in seriesMap){
//			var ds = new ChartDataset();
//			for(var j in map){
//				var cs = new ChartSet();
//				cs.value = seriesMap[i][j];
//				ds.addSet(cs);
//			}
//			ds.seriesName = i;
//			model.addChartDataset(ds);
//		}
//	}
//	return model;
//};


