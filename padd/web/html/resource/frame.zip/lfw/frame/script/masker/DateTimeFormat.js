DateTimeFormat.prototype = new AbstractSplitFormat();
/**
 * Ӣ�Ķ�����
 */
DateTimeFormat.enShortMonth = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
/**
 * Ӣ�ĳ����� 
 */
DateTimeFormat.enLongMonth = ["January","February","March","April","May","June","July","August","September","October","November","December"];
function DateTimeFormat(formatMeta){
	this.formatMeta = formatMeta;
}
	
DateTimeFormat.prototype.doOne = function(express){
	if(express.length() == 0)
		return new "";
	var obj = new Object;
	if(express == "yyyy"){
		obj.getValue = function(obj) {
			return this.getyyyy(obj);
		};
	}
	
	else if(express == "yy"){
		obj.getValue = function(obj) {
			return this.getyy(obj);
		};
	}
	if(express == "MMMM"){
		obj.getValue = function(obj) {
			return this.getMMMM(obj);
		};
	}
		
	if(express == "MMM"){
		obj.getValue = function(obj) {
			return this.getMMM(obj);
		};
	}
			
	if(express == "MM"){
		obj.getValue = function(obj) {
			return this.getMM(obj);
		};
	}
			
	if(express == "M"){
		obj.getValue = function(obj) {
			return this.getM(obj);
		};
	}
	
	if(express == "dd"){
		obj.getValue = function(obj) {
			return this.getdd(obj);
		};
	}
	
	if(express == "d"){
		obj.getValue = function(obj) {
			return this.getd(obj);
		};
	}
	
	if(express == "hh"){
		obj.getValue = function(obj) {
			return this.gethh(obj);
		};
	}
	
	if(express == "h"){
		obj.getValue = function(obj) {
			return this.geth(obj);
		};
	}
	
	if(express == "mm"){
		obj.getValue = function(obj) {
			return this.getmm(obj);
		};
	}
	
	if(express == "m"){
		obj.getValue = function(obj) {
			return this.getm(obj);
		};
	}
	
	if(express == "ss"){
		obj.getValue = function(obj) {
			return this.getss(obj);
		};
	}
	
	if(express == "s"){
		obj.getValue = function(obj) {
			return this.gets(obj);
		};
	}
	
	if(express == "HH"){
		obj.getValue = function(obj) {
			return this.getHH(obj);
		};
	}
	
	if(express == "H"){
		obj.getValue = function(obj) {
			return this.getH(obj);
		};
	}
	if(express == "t"){
		obj.getValue = function(obj) {
			return this.gett(obj);
		};
	}
	
	return express;
}
	
DateTimeFormat.prototype.getyyyy = function(date){
	return date.getYear();
}
	
DateTimeFormat.prototype.getyy = function(date){
	return String.valueOf(date.getYear()).substring(2);
}
	
DateTimeFormat.prototype.getM = function(date){
	return String.valueOf(date.getMonth());
}
	
DateTimeFormat.prototype.getMM = function(date){
	var month = date.getMonth();
	if(month < 10)
		return "0" + month;
	return month;
}
	
DateTimeFormat.prototype.getMMM = function(date){
	return DateFormat.enShortMonth[date.getMonth()-1];
}
	
DateTimeFormat.prototype.getMMMM = function(date){
	return DateFormat.enLongMonth[date.getMonth()-1];
}
	
DateTimeFormat.prototype.getdd = function(date){
		var day = date.getDate();
		if(day < 10)
			return "0" + day;
		return date.getDate()+"";
}
	
DateTimeFormat.prototype.getd = function(date){
		return date.getDate()+"";
	}
	
DateTimeFormat.prototype.gethh = function(date){
		var hh = date.getHours();
		if(hh < 10)
			return "0" + hh;
		
		return (date.getHours())+"";
	}
	
DateTimeFormat.prototype.geth = function(date){
		return (date.getHours())+"";
	}
	
DateTimeFormat.prototype.getHH = function(date){
		var HH = date.getHours();
		
		if(HH >= 12)
			HH = HH - 12;
		
		if(HH < 10)
			return "0" + HH;
		return (HH)+"";
	}
	
DateTimeFormat.prototype.getH = function(date){
		var HH = date.getHours();
		
		if(HH >= 12)
			HH = HH - 12;
		
		return (HH)+"";
	}
	
DateTimeFormat.prototype.getmm = function(date){
		var mm = date.getMinutes();
		if(mm < 10)
			return "0" + mm;
		
		return  (date.getMinutes())+"";
	}
	
DateTimeFormat.prototype.getm = function(date){
		return String.valueOf(date.getMinutes());
	}
	
DateTimeFormat.prototype.getss = function(date){
		var ss = date.getSeconds();
		if(ss < 10)
			return "0" + ss;
		
		return (ss)+"";
	}
	
DateTimeFormat.prototype.gets = function(date){
		return (date.getSeconds())+"";
	}
	
DateTimeFormat.prototype.gett = function(date){
		var hh = date.getHours();
		if(hh <= 12)
			return "AM";
		else
			return "PM";
	}
	
DateTimeFormat.prototype.getExpress = function() {
		return formatMeta.getFormat();
	}

DateTimeFormat.prototype.getReplaceds = function() {
		return ["",formatMeta.getSperatorSymbol(),":"];
	}

DateTimeFormat.prototype.getSeperators = function() {
		return ["(\\s)+?","-",":"];
	}

DateTimeFormat.prototype.getVarElement = function(express) {
		return doOne(express);
	}

DateTimeFormat.prototype.formatArgument = function(obj){
		return new DateTimeObject(obj);
	}
	