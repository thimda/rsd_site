function stopPropagation(e) {
	e = e || window.event;
	if (e.stopPropagation) {
		e.stopPropagation();
	} else {
		e.cancelBubble = true; // IE阻止冒泡方法
	}
}

var editingObj;// 正在被编辑的对象，一次只能编辑一个对象

function toEdit(e) {
	//e = EventUtil.getEvent()
	var obj = e.target;	
	//alert(obj.id);
	if(obj.className &&  (obj.className == 'editable' || obj.className == 'edit_selected')){
		toEditSelected(obj);
		//stopPropagation(e);
		stopEvent(e);
	}	
	
}
function toEditSelected(obj){
	if(obj){
		if(editingObj && obj.id != editingObj.id){ // 之前编辑的与现在选中的不同
			toEditAbleClass(editingObj);	
		}
		obj.className = 'edit_selected';
		editingObj = obj;
		// 在这里向后台发请求
		var parent = window.parent;
		if(parent){
			alert(parent.name);
		}
	}	
}

function toEditAbleClass(obj){
	if(obj)
		obj.className = 'editable';
}

function toEditAble(divId) {
	var obj = document.getElementById(divId);
	if (obj) {
		obj.className = 'editable';		
		EventUtil.addEventHandler(obj,'click',toEdit);
	
	}
}
