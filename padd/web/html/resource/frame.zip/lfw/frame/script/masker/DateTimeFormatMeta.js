DateTimeFormatMeta.prototype = new Object();
DateTimeFormatMeta.prototype.metaType = "DateTimeFormatMeta";
function DateTimeFormatMeta(){
}

/** ���ֳ���� */
DateTimeFormatMeta.prototype.yyyy = "yyyy";
	/** ���ֶ���� */
DateTimeFormatMeta.prototype.yy = "yy";
	/** Ӣ�ĳ��·� */
DateTimeFormatMeta.prototype.MMMM = "MMMM";
	/** Ӣ�Ķ��·� */
DateTimeFormatMeta.prototype.MMM = "MMM";
	/** ���ֳ��·� */
DateTimeFormatMeta.prototype.MM = "MM";
	/** ���ֶ��·� */
DateTimeFormatMeta.prototype.M = "M";
	/** ���ֳ����� */
DateTimeFormatMeta.prototype.dd = "dd";
	/** ���ֶ����� */
DateTimeFormatMeta.prototype.d = "d";
DateTimeFormatMeta.prototype.h = "h";
DateTimeFormatMeta.prototype.hh = "hh";
DateTimeFormatMeta.prototype.H = "H";
DateTimeFormatMeta.prototype.HH = "HH";
DateTimeFormatMeta.prototype.m = "m";
DateTimeFormatMeta.prototype.mm = "mm";
DateTimeFormatMeta.prototype.s = "s";
DateTimeFormatMeta.prototype.ss = "ss";
	/** am/pm */
DateTimeFormatMeta.prototype.t = "t";
DateTimeFormatMeta.prototype.format = "yyyy-M-d h:m:s";
DateTimeFormatMeta.prototype.speratorSymbol = "-";