/**
*��ʽ���
*/
FormatResult.prototype = new Object();
NumberFormat.prototype.value = null;
NumberFormat.prototype.color = null;
/**
*Ĭ�Ϲ��췽��
*/
function FormatResult(value, color){
  this.value = value;
  this.color = color;
}
