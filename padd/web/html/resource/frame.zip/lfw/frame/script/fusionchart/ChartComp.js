/**
 * 统计图表控件（基于FusionCharts）
 * 
 * @fileoverview 
 * 
 * @auther
 * @version NC6.0
 *  
 */

ChartComp.prototype = new BaseComponent;
ChartComp.prototype.componentType = "CHART";

/**
 * 构造方法
 * @class
 */
function ChartComp(parent, name, left, top, width, height, chartconfig, position, className) {
	if (arguments.length == 0)
		return;
	this.base = BaseComponent;
	this.base(name, left, top, width, height);

	this.parentOwner = parent;
	this.chartconfig = chartconfig;
	this.position = getString(position, "relative");
	this.className = getString(className, "chart_div");
	this.create();
};

/**
 * 主体创建函数
 */
ChartComp.prototype.create = function() {
	var oThis = this;
	this.Div_gen = $ce("div");
	this.Div_gen.id = this.id + "_div";
	this.Div_gen.style.position = this.position;
	this.Div_gen.style.left = this.left + "px";
	this.Div_gen.style.top = this.top + "px";
	this.Div_gen.style.width = this.width;
	this.Div_gen.style.height = this.height;
	//this.Div_gen.className = this.className;
	//this.Div_gen.style.background = "yellow";
	if (this.parentOwner)
		this.placeIn(this.parentOwner);
};

/**
 * 二级回调函数
 */
ChartComp.prototype.manageSelf = function() {
	this.chart = new FusionCharts(window.baseGlobalPath + "/frame/script/fusionchart/" + this.chartconfig.showType + ".swf", this.id, this.Div_gen.offsetWidth, this.Div_gen.offsetHeight, "0", "0");
};

ChartComp.prototype.onModelChanged = function(event) {
	var g = this.owner;
	// 行选中时
	if (RowSelectEvent.prototype.isPrototypeOf(event)) {
	}
	// 行选中撤销事件
	else if (RowUnSelectEvent.prototype.isPrototypeOf(event)) {
	}
	// cell数据改变时
	else if (DataChangeEvent.prototype.isPrototypeOf(event)) {
	}
	// 违反校验规则的事件
	else if (DataCheckEvent.prototype.isPrototypeOf(event)) {
		
	}
	// 整页数据更新
	else if (PageChangeEvent.prototype.isPrototypeOf(event)) {
		this.convertData();
		this.show();
	}
	// 插入新数据行
	else if (RowInsertEvent.prototype.isPrototypeOf(event)) {
		
	}
	// 删除行
	else if (RowDeleteEvent.prototype.isPrototypeOf(event)) {
		
	}
	else if (StateClearEvent.prototype.isPrototypeOf(event)) {
	}
};

/**
 * 绑定数据集
 */
ChartComp.prototype.setDataset = function(dataset) {
	this.dataset = dataset;
	dataset.bindComponent(this);
};

/**
 * 将dataset数据转换为图表所需数据
 */
ChartComp.prototype.convertData = function() {
	var convertor = new ChartModelConvertor(this.dataset, this.chartconfig);
	var chartModel = convertor.convert();
	var xml = chartModel.toXml();
	this.setDataXML(xml);
};

/**
 * 设置XML数据
 */
ChartComp.prototype.setDataXML = function(xml) {
	this.chart.setDataXML(xml);
};

/**
 * 设置XML文件地址
 */
ChartComp.prototype.setDataURL = function(url) {
	this.chart.setDataURL(url);
};

/**
 * 显示控件
 */
ChartComp.prototype.show = function() {
	this.chart.render(this.Div_gen.id);
};

/**
 * 获取对象信息
 */
ChartComp.prototype.getContext = function() {
	var context = new Object;
//	context.javaClass = "nc.uap.lfw.core.comp.ctx.ButtonContext";
	context.c = "";
	context.id = this.id;
	context.enabled = !this.disabled;
	return context;
};

/**
 * 设置对象信息
 */
ChartComp.prototype.setContext = function(context) {
	if (context.enabled == this.disabled)
		this.setActive(context.enabled);
	
};


// 单系列图形
ChartConfig.SINGLE_SERIES = "single-series";
// 多系列图形
ChartConfig.MULTI_SERIES = "multi-series";

/**
 * 图表配置对象
 */
function ChartConfig(showType, seriesType, caption, numberPrefix, groupColumn, groupName, seriesColumns, seriesNames, xAxisName, yAxisName) {
	// 显示图像类型
	this.showType = showType;
	// 图表显示系列类型（ChartConfig.SINGLE_SERIES、ChartConfig.MULTI_SERIES）
	this.seriesType = seriesType;
	// 图表标题
	this.caption = caption;
	// 统计结果数字前缀
	this.numberPrefix = numberPrefix;
	// 分组列
	this.groupColumn = groupColumn;
	// 分组列图表显示名称
	this.groupName = groupName;
	// 统计列
	if (seriesColumns != null)
		this.seriesColumns = seriesColumns.splits(",");
	// 统计列图表显示名称
	if (seriesNames != null)
		this.seriesNames = seriesNames.splits(",");
	// 横轴显示文字
	this.xAxisName = xAxisName;
	// 纵轴显示文字
	this.yAxisName = yAxisName;
};







