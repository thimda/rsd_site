function AbstractFormat() {	
}

AbstractFormat.prototype.format = function(obj){
	if(obj == null)
		return null;
		
	var fObj = formatArgument(obj);
	return innerFormat(fObj);
}
	
/**
 * ͳһ����ʽ������ṹ
 * 
 * @param obj
 * @return
 */
AbstractFormat.prototype.formatArgument = function(obj){
	
};
	
/**
 * ��ʽ��
 * 
 * @param obj
 * @return
 */
AbstractFormat.prototype.innerFormat = function(obj){
	
};