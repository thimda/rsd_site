/**
 * ���Ҹ�ʽ
 */
CurrencyFormat.prototype = new NumberFormat();
CurrencyFormat.prototype.formatMeta = null;
function CurrencyFormat(formatMeta){
	this.formatMeta = formatMeta;
};
/**
 * ���ظ�ʽ����
 * @param {} obj
 * @return {}
 */
NumberFormat.prototype.innerFormat = function(obj){
	var fo = (new NumberFormat(this.formatMeta)).innerFormat(obj);
	fo.setValue(fo.getValue().replace("$", fo.curSymbol));
	return fo;
};