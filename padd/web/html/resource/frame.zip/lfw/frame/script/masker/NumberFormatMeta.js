/**
 * @fileoverview �ַ�����ʽ����Ϣ
 * @author licza
 * @version NC6.0
 * 
 */
NumberFormatMeta.prototype = new Object();
NumberFormatMeta.prototype.metaType = "NumberFormatMeta";
function NumberFormatMeta(){
}
/**
*�Ƿ�������
*/
NumberFormatMeta.prototype.isNegRed = false;
NumberFormatMeta.prototype.isMarkEnable = false;
NumberFormatMeta.prototype.markSymbol = ",";
NumberFormatMeta.prototype.pointSymbol = ".";
NumberFormatMeta.prototype.positiveFormat = "n";
NumberFormatMeta.prototype.negativeFormat = "-n";

 