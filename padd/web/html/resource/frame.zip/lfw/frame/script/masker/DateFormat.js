/**
 * <b> ���ڸ�ʽ��  </b>
 *
 * <p>  
 *
 * </p>
 *
 * Create at 2009-3-20 ����08:50:32
 * 
 * @author bq 
 * @since V6.0
 */
DateFormat.prototype = new AbstractSplitFormat();
function DateFormat(formatMeta){
	 this.formatMeta = formatMeta;
}
