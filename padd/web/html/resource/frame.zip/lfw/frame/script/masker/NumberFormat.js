/**
 * <b> ���ָ�ʽ��  </b>
 *
 * <p> ��ʽ������ 
 *
 * </p>
 *
 * Create at 2009-3-20 ����08:50:32
 * 
 * @author bq 
 * @since V6.0
 */
NumberFormat.prototype = new Object();
NumberFormat.prototype.formatMeta = null;

/**
*��ʽ������
*/
NumberFormat.prototype.innerFormat = function (obj){
  var color, dValue, express, seperatorIndex, str, strValue, tmpValue;
  dValue = obj.f;
  tmpValue = dValue.value;
  if (tmpValue > 0) {
    express = 'n';
    strValue = '' + dValue.value;
  }
   else if (tmpValue < 0) {
    express = '-n';
    strValue = $substring('' + dValue.value, 1);
  }
   else {
    express = 'n';
    strValue = '' + dValue.value;
  }
  seperatorIndex = strValue.indexOf('.');
  str = new StringBuffer_0(strValue);
  seperatorIndex > 0 && $setCharAt(str, seperatorIndex, $toCharArray('.')[0]);
  this.setTheMark(str, seperatorIndex);
  color = null;
  if(dValue.value < 0 && this.formatMeta.isNegRed){
  	color = "FF0000";
  }	
  return new FormatResult($replaceAll(express, 'n', $toString(str.data)), color);
};
/**
*���ñ��
*/
NumberFormat.prototype.setTheMark = function ( str, seperatorIndex){
  var endIndex, first, index, mark;
  if (!this.formatMeta.isMarkEnable)
    return;
  seperatorIndex <= 0 && (seperatorIndex = $toString(str.data).length);
  first = $toString(str.data).charCodeAt(0);
  endIndex = 0;
  first == 45 && (endIndex = 1);
  mark = $toCharArray(this.formatMeta.markSymbol);
  index = seperatorIndex - 3;
  while (index > endIndex) {
    $insert(str, index, String.fromCharCode.apply(null, mark));
    index = index - 3;
  }
};
 
/**
*���췽��
*/
function NumberFormat(formatMeta){
  this.formatMeta = formatMeta;
}
/**
*Ĭ�Ϲ��췽��
*/
NumberFormat.prototype.formatArgument = function(obj){
	
}; 