function AbstractSplitFormat() {	
}

AbstractSplitFormat.prototype.format = function(obj){
	if(obj == null)
		return null;
		
	var fObj = formatArgument(obj);
	return innerFormat(fObj);
}
	
/**
 * ͳһ����ʽ������ṹ
 * 
 * @param obj
 * @return
 */
AbstractSplitFormat.prototype.formatArgument = function(obj){
	
};
	
/**
 * ��ʽ��
 * 
 * @param obj
 * @return
 */
AbstractSplitFormat.prototype.innerFormat = function(obj){
	this.doSplit();
	/*StringBuffer result = new StringBuffer();
	
	for(IElement element : elements){
		String elementValue = element.getValue(obj);
		if(elementValue != null)
			result.append(elementValue);
	}
			
	return new FormatResult(result.toString());
	*/
};

AbstractSplitFormat.prototype.getExpress = function() {
	
};

AbstractSplitFormat.prototype.doSplit = function(){
	var express = this.getExpress();
		
	if(this.elements == null || this.elements.size() == 0)
		this.elements = this.doQuotation(express, this.getSeperators(), this.getReplaceds(), 0);
};


/**
 * ��������
 * 
 * @param express
 * @param seperators
 * @param replaced
 * @param curSeperator
 * @param obj
 * @param result
 */
AbstractSplitFormat.prototype.doQuotation = function(express, seperators, replaced, curSeperator){
	if(express.length() == 0)
		return null;
		
	var elements = new Array;
		
//	Pattern pattern  = Pattern.compile("\".*?\"");
//	Matcher matcher = pattern.matcher(express);
//		
//	int fromIndex = 0;
//	while(matcher.find()){
//		int i = matcher.start();
//		int j = matcher.end();
//		if(i != j){
//			if(fromIndex < i){
//				List<IElement> childElements = doSeperator(express.substring(fromIndex, i), seperators, replaced, curSeperator);
//				if(childElements != null && childElements.size() > 0)
//					elements.addAll(childElements);
//			}
//			
//			elements.add(new StringElement(express.substring(i + 1, j-1)));
//			
//			fromIndex = j;
//		}
//	}
//	
//	if(fromIndex < express.length()){
//		List<IElement> childElements = doSeperator(express.substring(fromIndex, express.length()), seperators, replaced, curSeperator);
//		if(childElements != null && childElements.size() > 0)
//			elements.addAll(childElements);
//	}
//	
	return elements;
}
	
/**
 * ���������ָ���
 * 
 * @param express
 * @param seperators
 * @param replaced
 * @param curSeperator
 * @param obj
 * @param result
 */
AbstractSplitFormat.prototype.doSeperator = function(express, seperators, replaced, curSeperator){
	if(curSeperator >= seperators.length){
		var elements = new Array;
		elements.add(getVarElement(express));
		return elements;
	}
		
	if(express.length() == 0)
		return null;
		
	var elements = new Array;
		
//	Pattern pattern  = Pattern.compile(seperators[curSeperator]);
//	Matcher matcher = pattern.matcher(express);
//	
//	int fromIndex = 0;
//	while(matcher.find()){
//		int i = matcher.start();
//		int j = matcher.end();
//		if(i != j){
//			if(fromIndex < i){
//				List<IElement> childElements = doSeperator(express.substring(fromIndex, i), seperators, replaced, curSeperator + 1);
//				if(childElements != null && childElements.size() > 0)
//					elements.addAll(childElements);
//			}
//			
//			if(replaced[curSeperator] != null){
//				elements.add(new StringElement(replaced[curSeperator]));
//			}
//			else{
//				elements.add(new StringElement(express.substring(i, j)));
//			}
//			
//			fromIndex = j;
//		}
//	}
//	
//	if(fromIndex < express.length()){
//		List<IElement> childElements = doSeperator(express.substring(fromIndex, express.length()), seperators, replaced, curSeperator + 1);
//		if(childElements != null && childElements.size() > 0)
//			elements.addAll(childElements);
//	}
	return elements;
};