/**
 * 统计图表数据模型
 * @param config 图表配置信息
 */
function ChartModel(config) {
	this.config = config;
	this.categories = null;
	this.datasets = null;
};

ChartModel.prototype.toXml = function() {
	// 系列类型
	var seriesType = getString(this.config.seriesType, ChartConfig.SINGLE_SERIES);;
	
	var str = '<chart caption="' + this.config.caption + '" xAxisName="' + this.config.xAxisName + '" yAxisName="' + this.config.yAxisName + '" numberPrefix="' + this.config.numberPrefix + '" showValues="0">\n';
	if (seriesType == ChartConfig.SINGLE_SERIES) {  // 单系列图形
		if (this.datasets != null && this.datasets.length >= 1) {
			str += this.datasets[0].toXml();
		}
	}
	else if (seriesType == ChartConfig.MULTI_SERIES) {  // 多系列图形
		if (this.categories != null) {
			str += "<categories>\n";
			for (var i = 0; i < this.categories.length; i ++) {
				str += this.categories[i].toXml();
			}
			str += "</categories>\n";
		}
		if (this.datasets != null) {
			for (var i = 0; i < this.datasets.length; i ++) {
				var dataset = this.datasets[i];
				str += '<dataset seriesName="' + dataset.seriesName + '">\n';
				str += dataset.toXml();
				str += '</dataset>\n';
			}
		}
	}
	str += "</chart>\n";
	return str;
};

ChartModel.prototype.addCategory = function(cate) {
	if(this.categories == null)
		this.categories = new Array;
	this.categories.push(cate);
};

ChartModel.prototype.addChartDataset = function(ds) {
	if(this.datasets == null)
		this.datasets = new Array;
	this.datasets.push(ds);
};

/**
 * 分组信息
 */
function Category() {
	this.label = null;
};

Category.prototype.toXml = function() {
	var str = '<category label="' + this.label + '"';
	str += ' />\n';
	return str;
};

/**
 * 图表数据集合
 */
function ChartDataset() {
	this.seriesName = null;
	this.chartsets = null;
};

ChartDataset.prototype.toXml = function() {
	var str = "";
	if (this.chartsets != null) {
		for (var i = 0; i < this.chartsets.length; i ++) {
			str += this.chartsets[i].toXml();
		}
	}
	return str;
};

ChartDataset.prototype.addSet = function(set) {
	if (this.chartsets == null)
		this.chartsets = new Array;
	this.chartsets.push(set);
};

/**
 * 数据
 */
function ChartSet() {
	this.label = null;
	this.value = null;
	//TODO
//	this.toolTip = null;
//	this.link = null;
//	this.showLable = "1";
};

ChartSet.prototype.toXml = function() {
	var str = '<set value="' + this.value + '"';
	if (this.label != null)
		str += ' label="' + this.label + '"';
	//TODO
//	if (this.toolTip != null)
//		str += ' toolTip="' + this.toolTip + '"';
//	if (this.link != null)
//		str += ' link="' + this.link + '"';
//	if (this.showLable != null)
//		str += ' showLable="' + this.showLable + '"';
	str += ' />\n';
	return str;
};



