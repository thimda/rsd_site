//var IBillStatus = new Object;
////审批未通过
//IBillStatus.NOPASS = 0;
////审批通过
//IBillStatus.CHECKPASS = 1;
////审批进行中
//IBillStatus.CHECKGOING = 2;
////提交状态
//IBillStatus.COMMIT = 3;
////作废状态
//IBillStatus.DELETE = 4;
////冲销状态
//IBillStatus.CX = 5;
////终止(结算）态
//IBillStatus.ENDED = 6;
////冻结状态
//IBillStatus.FREEZE = 7;
////自由态
//IBillStatus.FREE = 8;
////
//IBillStatus.ALL = 30;

	/*为借款报销定制**/
	//IBillStatus.COMMIT = -1;//审批状态——初始状态

	//IBillStatus.CHECKGOING = 0;//审批状态——审批中

	//IBillStatus.CHECKPASS = 1;//审批状态——审批通过

	//IBillStatus.NOPASS = 2;//审批状态——审批未通过
	//IBillStatus.REJECT = 3;//审批状态——审批驳回
	
	
//	IBillStatus.DJZT_TempSaved = 0;  //单据状态——暂存
//	IBillStatus.DJZT_Saved = 1;	//单据状态——保存
//	IBillStatus.DJZT_Verified = 2;//单据状态——审核
//	IBillStatus.DJZT_Sign = 3;	//单据状态——签字